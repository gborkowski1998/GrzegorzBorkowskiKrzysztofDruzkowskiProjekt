﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace WeatherREST_API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherByCityController : ControllerBase
    {
        private readonly ILogger<WeatherByCityController> _logger;

        public WeatherByCityController(ILogger<WeatherByCityController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IEnumerable<WeatherByCity> Get([FromQuery(Name = "city")] string city)
        {
            var rng = new Random();
            return Enumerable.Range(1, 5).Select(indexGreg => new WeatherByCity
            {
                Date = DateTime.Now.AddDays(indexGreg),
                TemperatureC = rng.Next(-20, 55),
                City = city
            })
            .ToArray();
        }
    }
}