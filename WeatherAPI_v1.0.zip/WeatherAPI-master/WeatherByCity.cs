using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;

namespace WeatherREST_API
{
    public class WeatherByCity
    {
        public DateTime Date { get; set; }

        public int TemperatureC { get; set; }

        public string City { get; set; }
    }
}
