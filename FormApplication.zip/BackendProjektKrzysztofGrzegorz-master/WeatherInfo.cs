﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackendProjectKrzysztofGrzegorz
{
    class WeatherInfo
    {
        public DateTime Date { get; set; }

        public int TemperatureC { get; set; }

        public string City { get; set; }
    }
}
