﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using System.Net.Http.Formatting;

namespace BackendProjectKrzysztofGrzegorz
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:50014");

            HttpResponseMessage response = client.GetAsync("/WeatherByCity").Result;

            var emp = response.Content.ReadAsAsync<IEnumerable<WeatherInfo>>().Result;

            dataGridView1.DataSource = emp;
        }
    }
}
